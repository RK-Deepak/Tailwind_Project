let opemmenu=document.querySelector("#openmenu");
let removemenu=document.querySelector("#cross");
let menu=document.querySelector("#menu");


opemmenu.addEventListener("click",()=>
{
      menu.style.transform="translateX(0)";
      menu.style.opacity="1";
})
removemenu.addEventListener("click",()=>
{
      menu.style.transform="translateX(21.25rem)";
      menu.style.opacity="0";
})
//to remvoe sliebar if we click somewhere lese on screen
document.addEventListener("click",(e)=>
{
          //we apply even listerner on document ke agar document pe click krenge  or woh jo click kiya hai woh openmenu wala button nhi hai and sath me menu wala divv bhi nhi hai toh hatad o0
          if(!opemmenu.contains(e.target) && !menu.contains(e.target))
          {
                    menu.style.transform="translateX(21.25rem)"; 
                    menu.style.opacity="0";
          }
          //WHEN WE CLICK ON hyperlink slidebar disappear
          if(e.target.tagName==="A")
          {
                    menu.style.transform="translateX(21.25rem)";    
                    menu.style.opacity="1";
          }
         
})